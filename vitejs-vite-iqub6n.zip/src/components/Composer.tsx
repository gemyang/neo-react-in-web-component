// import { NoContentAgent } from "../components/NoContentAgent";
// import { TwoTabCarousel } from "../components/TwoTabCarousel";
import { AdvancedTable } from './AdvancedTable';
// import { TwoCheckboxes } from "../components/Checkboxes";

export const Composer = () => <AdvancedTable></AdvancedTable>;
